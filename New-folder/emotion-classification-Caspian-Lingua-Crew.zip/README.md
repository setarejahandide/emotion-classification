
# emotion-classification

pleaser run main.py
there are instructions in the main file, you can either 
1. upload the isear-test.csv file to see the accuracy scores of this emotion classifier
2. give the model any sentence and the model will predict the emotion associated with it


extra notes:

if you want to checkout the performance of the classifier without additional inguistic features, please run logistic-regression-without-linguistic-features.py

if you want to check out the baseline, run NaiveBayes.py
